package cwc.temp.services;


public interface Conversion {
    
    double fahrenheitToCelcius(double fahrenheitTemp);
    
    double celciusToFahrenheit(double celciusTemp);
    
    double celciusToKelvin(double celciusTemp);
}
